<?php
// MySQL connection class

$user = "youruser";
$pass = "yourpass";
$host = "localhost";
$db = "stats";

$conn = mysql_connect($host, $user, $pass) or die('could not connect');

if (!$conn) {
	echo "could not connect";
}

$selectDB = mysql_select_db($db) or die("Failed to select DB");

if (!$selectDB) {
	echo "couldn not select db";
}

?>
