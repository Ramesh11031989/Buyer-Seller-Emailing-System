<?php
//Include the Class
require("cPanel.php");

$domain = "your domain"; // www is not always needed
$port = "2082";			 // the port that cpanel runs on
$user = "your cpanel user";
$pass = "your cpanel pass";
$siteNum = 0;			// number for site ID in database

// update the awstats before fetching?
$updateStats = false;

// update the database? 
$updateDB = false;

// initialize the class
$cp = new cPanel($domain,$port,$user,$pass);

// url for if we want to update 
if ($updateStats == true) {
	echo $cp->fetchPage('awstats.pl?config='.$domain.'&ssl=&lang=en&framename=mainright&update=1');
}
// this one just views it
else {
	$var = $cp->fetchPage('awstats.pl?config='.$domain.'&amp;ssl=&amp;lang=en&amp;framename=mainright');
}


/*
* DATA CRUNCHING TIME - Very Basic For Now
*/

// replace all of the tags ( this is done to help parse)
$var = str_replace('&nbsp;', '', $var);
$var = str_replace('|||||', '|', $var);
$var = str_replace('||||', '|', $var);
$var = str_replace('|||', '|', $var);
$var = str_replace('||', '|', $var);

// strip all tags except td, b and tr
$var = strip_tags($var, "<td>,<b>,<tr>");

//match the string
preg_match('/Update:(.*)>(.*?)Update/', $var, $matches);

$reportDate = strip_tags($matches[2]);


// get the traffic viewed number
preg_match('/Traffic viewed(.*?)<\/tr>/', $var, $matches);

// match that
$var = $matches[1];

// replace and remove stuff
$var = str_replace('<b>', '|', $var);
$var = str_replace('</b>', '|', $var);
$var = strip_tags($var);
$var = str_replace('||', '|', $var);

// explode into an array
$var_array = explode("|", $var);


// create the timestamp 18 Feb 2008 - 23:07
$tmp = explode('-',$reportDate);
$timestamp = strtotime($tmp[0].$tmp[1]);

$tmp = "";


if ($updateDB == true) {
	include("class.mysql.php");

	$query = mysql_query("INSERT INTO `stats` (`id`, `site_id`, `date`, `uniques`, `visits`, `visits_visitor`, `pages`, `pages_visitor`, `hits`, `hits_visitor`, `bandwidth`, `bandwidth_visitor`) VALUES (NULL, '".$siteNum."', '".$timestamp."', '".$var_array[1]."', '".$var_array[2]."', '".$var_array[3]."', '".$var_array[4]."', '".$var_array[5]."', '".$var_array[6]."', '".$var_array[7]."', '".$var_array[8]."', '".$var_array[9]."');");

	if ($query) {
		echo "Query Ran Successfully";
	}
	else {
		echo "Query Failed";
	}
}
else {
	echo "Num: ".$siteNum." Date: ".unixtojd($timestamp)." uniques: ".$var_array[1]." visits: ".$var_array[2]." visits per visitor: ".$var_array[3]." pages: ".$var_array[4]." pages per visitor: ".$var_array[5]." hits: ".$var_array[6]." hits per visitor: ".$var_array[7]." bandwidth: ".$var_array[8]." bandwidth per visitor: ".$var_array[9]."<br/>";
}


?>
