 <?php
 class cPanel{
 	var $cPanelUser   = "";
 	var $cPanelPass   = "";
 	var $cPanelDomain = "";
 	var $cPanelPort   = 0;
 	var $cPanelRel    = "";
 	var $cPanelRoot   = "";

 	function cPanel($cPanelDomain, $cPanelPort, $authUser, $authPass) {
 		$this->cPanelDomain = $cPanelDomain;
 		$this->cPanelPort = $cPanelPort;
 		$this->cPanelUser = $authUser;
 		$this->cPanelPass = $authPass;
 		//Root path of cPanel to load pages begining with /
 		
 		$this->cPanelRoot = "http://".$this->cPanelDomain.":".$this->cPanelPort."/";
 		//Relative path of cPanel to load pages not begining with /
 		$other_path = 'frontend/x3/';
 		$this->cPanelRel = $this->cPanelRoot."";
 	}
 	function fetchPage($cPanelPage) {
 		$curl = curl_init();
 		$loginf = sprintf("%s:%s", $this->cPanelUser, $this->cPanelPass);
 		
 		//Build the path. If it begins with / we go and paste at root
 		if ($cPanelPage[0] == '/') {
 			$url = $this->cPanelRoot.substr($cPanelPage, 1);
 		}
 		else {
 			//Build the path - if begins with / we go and paste relative
 			$url = $this->cPanelRel.$cPanelPage;
 		}
 		
 		
 		curl_setopt ($curl, CURLOPT_URL, $url);
 		curl_setopt ($curl, CURLOPT_TIMEOUT, 30);
 		curl_setopt ($curl, CURLOPT_USERAGENT, sprintf("Mozilla/%d.0",rand(4,5)));
 		curl_setopt ($curl, CURLOPT_HEADER, 0);
 		curl_setopt ($curl, CURLOPT_RETURNTRANSFER, 1);
 		curl_setopt ($curl, CURLOPT_SSL_VERIFYPEER, 0);
 		curl_setopt ($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
 		curl_setopt ($curl, CURLOPT_USERPWD, $loginf);
 		$html = curl_exec ($curl);
 		curl_close ($curl);
 		
 		//print_r($url);
 		return $html;
 	}

 }
?> 
