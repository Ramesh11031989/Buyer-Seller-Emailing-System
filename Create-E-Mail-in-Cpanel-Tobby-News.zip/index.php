<?php
//Tobby News(www.tobbynews.com
//created by Praveen
?>
<style>
.button{
padding: 6px;
background: #EE4444;
border: none;
color: #fff;
cursor: pointer;
}
input {
text-align: right;
float: right;
}
</style>
<?php 
$cp_user = 'username'; // cPanel username
$cp_pass = 'password'; // cPanel password
$cp_domain = 'your_domain_name'; // cPanel domain or IP
$cp_skin = 'x3';  // cPanel skin, Mostly x3. 
$e_pass = 'password'; // email password
$e_domain = 'your_domain_name'; // email domain (same as cPanel domain above)
$e_quota = 100; // amount of space in megabytes
$e_pass1= '';
$captcha=true;
function post($root, $ech = '') {
  if (isset($_REQUEST[$root]))
    return $_REQUEST[$root];
  else 
    return $ech;
}

// get the values from the form
$user = post('user', '');
$e_pass = post('password1', $e_pass);
$e_domain = post('domain', $e_domain);
$e_quota = post('quota', $e_quota);
$e_pass1 = post('password2', $e_pass1);
$message = '';

if (!empty($user))
while(true) {
	if ($captcha) {
    @session_start(); // start session if not started yet
    if ($_SESSION['captcha'] != $_REQUEST['captcha_txt']) {
      // set antispam string to something random, in order to avoid reusing it once again
      $_SESSION['captcha'] = rand(1,9999999);
  
      // let user know incorrect code entered
      $msg = '<h2 style="color:red">Incorrect antispam code entered.</h2>';
      break;
    }
    else {
      // set captcha string to something random, in order to avoid reusing it once again
      $_SESSION['captcha'] = rand(1,9999999);
    }
  }

if($epass==$epass1)
{

  // Create email account process starts
  //open the cpanel url
  $url = fopen ("http://$cp_user:$cp_pass@$cp_domain:2082/frontend/$cp_skin/mail/doaddpop.html?email=$user&domain=$e_domain&password=$e_pass&quota=$e_quota", "r");
  if (!$url) {
    $message = 'Unable to create email account. Possible reasons: "fopen" function allowed on your server, PHP is running in SAFE mode';
    break;
  }

  $message = "Email account {$user}@{$e_domain} created.";

  // Check result
  while (!feof ($url)) {
    $line = fgets ($url, 1024);
    if (ereg ("already exists", $line, $out)) {
      $message = "Email ID {$user}@{$e_domain} already exists.";
      break;
    }
  }
  @fclose($url);
  break;
}
else
{
$error="Password Mismatch";	//echo $error;
break;
}
}
?>
<html>
<head>
<title>cPanel Email ID Creator-Tobby News</title>
</head>
<body>
<div style="margin:0 auto;width: 600px;background: bisque;border-radius: 20px;padding: 20px;">
<h1>cPanel Email ID Creator-Tobby News</h1>
	<?php if($message){ ?>
		<script> 
			alert("<?php  echo $message?>");
 		</script>
 	<?php }?>
    <div style="margin:0 auto;">
    <?php if(isset($error)){ echo $error; } if(isset($msg)){ echo $msg; }
	?>
<form name="register" method="post">
<div style="margin: 0 auto;background: darksalmon;padding: 20px;border-radius: 20px; width:300px;height: 245px;">
<p>
Username:					
<input name="user" size="20" value="" /> </p>
<p>   
Password:					
<input name="password1" size="20" type="password" /></p>
<p>      
Re-type Password:					
<input name="password2" size="20" type="password" /></p>
<p>Captcha</p>
<p >
<?php if ($captcha) { ?>
<img src="captcha.php" alt="CAPTCHA" /><input name="captcha_txt" size="20" /></p>
<?php } ?>     <p style="text-align:center;">
<input name="submit" type="submit" value="Create Email Account" class="button"/></p></div>
</form>
</div>
</div>
</body>
</html>