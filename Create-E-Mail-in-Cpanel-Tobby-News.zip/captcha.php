<?php
//Tobby News(www.tobbynews.com)
//created by Praveen 
$font='arial.ttf';
$charset = '0123456789';
$code_length = 6;
$height = 30;
$width = 100;
@session_start();
$code = '';
for($i=0; $i < $code_length; $i++) {
  $code = $code . substr($charset, mt_rand(0, strlen($charset) - 1), 1);
}
$font_size = $height * 0.7;
$image = @imagecreate($width, $height)or die("Cannot Initialize new GD image stream");
$background_color = @imagecolorallocate($image, 0, 0, 0);
/* render text */
$text_color = @imagecolorallocate($image, 20, 40, 100);
@imagettftext($image, $font_size, 0, 0,$font_size,$text_color, $font , $code)or die('Cannot render TTF text.');
//setting the page type to  image
header('Content-Type: image/png');
@imagepng($image) or die('imagepng error!');
@imagedestroy($image);
// sending the captcha code to session
$_SESSION['captcha'] = $code;
exit();
?>